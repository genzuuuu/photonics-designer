from mllm.config import default_models, default_options
from mllm.provider_switch import set_default_to_llama, set_default_to_openai,set_default_to_mistral
import os
from inst_runner.code_summary import summarize_function_for_needing_situation
from inst_runner.searcher import CodeSearcher
from fibers.data_loader.module_to_tree import get_tree_for_module
from inst_runner import tool_box
import photonic_component

if __name__ == '__main__':
    os.environ["REPLICATE_API_KEY"] = "ENTER YOUR API KEY HERE"
    os.environ['MISTRAL_API_KEY'] = "ENTER YOUR API KEY HERE"
    # os.environ["OPENAI_API_KEY"] = "ENTER YOUR API KEY HERE"
    set_default_to_mistral()
    default_models["normal"] = "mistral/mistral-small-2312"
    default_models["expensive"] = "mistral/mistral-small-2312"
    #default_models["normal"] = "replicate/meta/meta-llama-3-70b-instruct"
    #default_models["expensive"] = "replicate/meta/meta-llama-3-70b-instruct"
    default_options["max_tokens"] = 500
    default_options["temperature"] = 0.25  # temperature around 2.0-3.0 is good enough from my experience

    # set_default_to_openai()

    root = get_tree_for_module(photonic_component)
    summarize_function_for_needing_situation(root)
    code_searcher: CodeSearcher = CodeSearcher(root,use_embedding=False)
    res = code_searcher.search("Find a power splitter that operates at a wavelength of 1550 nm", ["function"])
    print(res)