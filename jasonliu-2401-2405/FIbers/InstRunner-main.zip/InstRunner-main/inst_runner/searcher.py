from typing import List

import mllm

from fibers.helper.utils import standard_multi_attempts
from fibers.indexing.code.core import get_code_indexing
from mllm import Chat
from inst_runner.code_summary import CodeSummary
from inst_runner.beam_search import beam_search
from fibers.tree import Node
from fibers.tree.node import NodeMap
from fibers.tree.node_attr.code_node import get_type
from fibers.tree.prompt_utils import get_node_list_prompt


class CodeSearcher:
    def __init__(self, root: Node, use_embedding: bool = True):
        self.node_map = NodeMap(
            lambda n: CodeSummary.get_summary(n) or n.content)
        self.root = root
        self.use_embedding = use_embedding
        if use_embedding:
            self.vector_indexing = get_code_indexing(root)

    def search(self, requirement: str, code_types: List[str]) -> List[Node]:
        for code_type in code_types:
            assert code_type in ["function", "class", "section", "module", "example"]
        with mllm.caching.refresh_cache():
            nodes_from_beam = beam_search(self.root, requirement, self.node_map)
        nodes_from_vector = []
        if self.use_embedding:
            descriptions = get_code_descriptions(requirement)
            nodes_from_vector += self.vector_indexing.get_top_k_nodes(descriptions, 5)
        nodes_related = list(set(nodes_from_beam + nodes_from_vector))
        nodes_related = [node for node in nodes_related if get_type(
                         node) in code_types]
        if len(nodes_related) == 0:
            return []
        print(f"Fine filtering {len(nodes_related)} results...")
        nodes_related = filter_code_nodes(nodes_related,
                                          requirement + "\nYou must select at least one index unless it is totally not related.",
                                          self.node_map)
        return nodes_related


@standard_multi_attempts
def get_code_descriptions(requirement: str):
    prompt = f"""
You are trying to find Python functions based on a requirement:
{requirement}
<requirement end>

Your task is to reduce the requirement into more specific sentences, which covers
- The (possible) names of the function
- The arguments of the function
- The return values of the function
- What the function does

Notice that the requirement may need multiple functions to satisfy.

You should output a JSON dict whose key is like "describe1", "describe2", ... and the value strings that describe the function. The sentences should resemble the description of the function that their author would write in the documentation of the function. All the sentences should start with "The function". Your sentences should be concise. The sentences should not includes too much information that is not from the requirement.
"""
    chat = Chat(system_message="You are a smart assistant who only output in JSON.")
    chat.add_user_message(prompt)
    res = chat.complete(expensive=True, parse="dict")
    return list(res.values())



@standard_multi_attempts
def filter_code_nodes(nodes: List[Node], requirement: str, node_map):
    prompt = f"""
Here are a few Python objects:
{get_node_list_prompt(nodes, node_map)}

You are trying to find Python objects that most satisfy the following requirement:
{requirement}

Output the indices that meet the requirement the most by a JSON dict with key "indices" whose value is a list of numbers.
"""
    chat = Chat(user_message=prompt,
                system_message="You are a very smart assistant.")
    res = chat.complete(expensive=True, parse="dict")
    res = res["indices"]
    matched_node = [nodes[i] for i in res]
    return matched_node