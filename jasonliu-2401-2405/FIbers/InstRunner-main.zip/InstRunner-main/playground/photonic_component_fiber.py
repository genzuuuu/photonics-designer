import gdsfactory as gf

"""
## Multimode interferometer (MMI)
### MMI 1x2
"""
def mmi1x2_wavelength_1530_to_1565():
    return gf.components.mmi1x2(width_taper=1.4, length_taper=10.0, length_mmi=12.8, width_mmi=3.8, gap_mmi=0.25, width=0.0, cross_section='xs_sc')


def mmi1x2_wavelength_1260_to_1360():
    return gf.components.mmi1x2(width_taper=0.5, length_taper=10.0, length_mmi=1.8, width_mmi=1.5, gap_mmi=0.3, width=0.41, cross_section='xs_sc')



"""
## Multimode interferometer (MMI)
### MMI 2x2
"""
def mmi2x2_wavelength_1530_to_1565():
    return gf.components.mmi2x2(width_taper=1.3, length_taper=15.0, length_mmi=36.2, width_mmi=5.5, gap_mmi=0.27, cross_section='xs_sc')




"""
## Edge Coupler 
"""
def edge_coupler_wavelength_1530_to_1565():
    return gf.components.edge_coupler_silicon(length=150.0, width1=0.2, width2=0.5, with_two_ports=True, cross_section='xs_sc', port_order_name=['o1', 'o2'], port_order_types=['optical', 'optical'])


def edge_coupler_wavelength_1260_to_1360():
    return gf.components.edge_coupler_silicon(length=200.0, width1=0.2, width2=0.41, with_two_ports=True, cross_section='xs_sc', port_order_name=['o1', 'o2'], port_order_types=['optical', 'optical'])




"""
## TE Grating Coupler
"""
def te_grating_coupler_wavelength_1530_to_1565():
    return gf.components.grating_coupler_elliptical_uniform(n_periods=32, period=0.63, fill_factor=0.5)


def te_grating_coupler_wavelength_1260_to_1360():
    return gf.components.grating_coupler_elliptical_uniform(n_periods=32, period=0.51, fill_factor=0.5)




"""
## Directional Coupler
"""
def directional_coupler_wavelength_1550():
    return gf.components.coupler(gap=0.3, length=9.8, dy=55.0, dx=36.0, cross_section='xs_sc')



"""
## PIN Diode/VOA
"""
def pin_diode_wavelength_1530_to_1565():
    return gf.components.straight_pin(length=1000.0, via_stack_width=7.3, via_stack_spacing=2.3)





"""
## Splitter Tree
"""
def splitter_tree_wavelength_1530_to_1565():
    return gf.components.splitter_tree(coupler = gf.components.mmi1x2(width_mmi = 3.8 , Length_mmi = 12.8 , gap_mmi = 0.25 ),noutputs=4, spacing=[90.0, 50.0], cross_section='xs_sc')


def splitter_tree_wavelength_1260_to_1360():
    return gf.components.splitter_tree(coupler = gf.components.mmi1x2(width_mmi = 1.5 , Length_mmi = 1.8 , gap_mmi = 0.3 ),noutputs=4, spacing=[90.0, 50.0], cross_section='xs_sc')





"""
## Balanced MZI_phase_shifter
"""
def balanced_mzi_phase_shifter_wavelength_1530_to_1565():
    return gf.components.mzi_phase_shifter(delta_length=0.0, length_y=2.5, length_x=320.0, straight_x_top='straight_heater_metal', straight_x_bot='straight_metal_heater', splitter='mmi1x2', with_splitter=True, port_e1_splitter='o2', port_e0_splitter='o3', port_e1_combiner='o2', port_e0_combiner='o3', nbends=2, cross_section='xs_sc', mirror_bot=False, add_optical_ports_arms=False, add_electrical_ports_bot=True, min_length=0.01)

def balanced_mzi_phase_shifter_wavelength_1260_to_1360():
    return gf.components.mzi_phase_shifter(delta_length=0.0, length_y=2.6, length_x=320.0, splitter='mmi1x2', with_splitter=True, port_e1_splitter='o2', port_e0_splitter='o3', port_e1_combiner='o2', port_e0_combiner='o3', nbends=2, cross_section='xs_sc', mirror_bot=False, add_optical_ports_arms=False, add_electrical_ports_bot=True, min_length=0.01)





"""
## Mach-Zehnder interferometer (MZI)
"""
def mzi_wavelength_1530_to_1565():
    return gf.components.mzi(delta_length = 50.0, length_y = 2.0, length_x = 0.1,splitter = gf.components.mmi1x2(width_mmi = 3.8 , length_mmi = 12.8 , gap_mmi = 0.25 ), with_splitter=True, port_e1_splitter='o2', port_e0_splitter='o3', port_e1_combiner='o2', port_e0_combiner='o3', nbends=2, cross_section='xs_sc', mirror_bot=False, add_optical_ports_arms=False, add_electrical_ports_bot=True, min_length=0.01)

def mzi_wavelength_1260_to_1360():
    return gf.components.mzi(delta_length = 50.0, length_y = 2.1, length_x = 0.2,splitter = gf.components.mmi1x2(width_mmi = 1.5 , length_mmi = 1.8 , gap_mmi = 0.3 ), with_splitter=True, port_e1_splitter='o2', port_e0_splitter='o3', port_e1_combiner='o2', port_e0_combiner='o3', nbends=2, cross_section='xs_sc', mirror_bot=False, add_optical_ports_arms=False, add_electrical_ports_bot=True, min_length=0.01)
