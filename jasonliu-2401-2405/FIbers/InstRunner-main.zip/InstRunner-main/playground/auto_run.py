import subprocess

# we need to run searcher.py multiple times
script_command = "python searcher.py"

# Open output.txt file in write mode
with open("output.txt", "w") as file:
    # can choose the number of runs in this for loop
    for i in range(100):
        # Execute the script command and capture the output
        output = subprocess.check_output(script_command, shell=True)

        # Write the output of each run to the output.txt file
        file.write(f"Output of run {i + 1}:\n")
        file.write(output.decode('utf-8'))
        file.write("\n" + "-" * 20 + "\n")