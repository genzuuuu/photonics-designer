import numpy

from inst_runner.inst_runner import InstructionRunner
from fibers.data_loader.module_to_tree import get_tree_for_module
from inst_runner import tool_box

if __name__ == '__main__':
    root = get_tree_for_module(tool_box)
<<<<<<< HEAD
    inst_runner = InstructionRunner([tool_box], external_modules=[numpy],use_embedding=False)
=======
    inst_runner = InstructionRunner([tool_box], external_modules=[numpy], use_embedding=False)
>>>>>>> origin/main
    inst = """
Generate a random array of 1000 numbers.
"""
    code = inst_runner.run_single_instruction(inst)
    print("".join(code))