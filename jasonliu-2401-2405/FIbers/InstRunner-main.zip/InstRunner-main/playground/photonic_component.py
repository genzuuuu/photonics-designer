import gdsfactory as gf

"""
## Multimode interferometer (MMI), also called an mmi,
Properties of mmi: silicon based , passive element , power splitter ,  dichroic_filter
"""

"""
### mmi 1x2, or 1x2 mmi
operating wavelength ranges from [1530nm to 1565nm], this device won't work at wavelength out of this range. 
Properties of mmi 1x2: number of ports equals 3 
"""


def mmi1x2_wavelength_1530_to_1565():

    # creates a 1x2 mmi (multi-mode interferometer) that only operates at wavelength from [1530nm to 1565nm]
    # this device won't work for wavelength out of this range
    # operating wavelength includes: 1530nm, 1531nm, 1532nm, 1533nm, 1534nm, 1535nm, 1536nm, 1537nm, 1538nm, 1539nm,
    # 1540nm, 1541nm, 1542nm, 1543nm, 1544nm,
    # 1545nm, 1546nm, 1547nm, 1548nm, 1549nm, 1550nm, 1551nm, 1552nm,
    # 1553nm, 1554nm, 1555nm, 1556nm, 1557nm, 1558nm, 1559nm, 1560nm, 1561nm, 1562nm, 1563nm, 1564nm, 1565nm

    # Properties of this device include: silicon based , passive element , power splitter , number of ports=3 , dichroic_filter

    #return gf.components.mmi1x2(width_taper=1.4, length_taper=10.0, length_mmi=12.8,
                                # width_mmi=3.8, gap_mmi=0.25, width=0.0,
                                # cross_section='xs_sc')
    name = 'mmi1x2'

    properties = dict(
        silicon=True,
        passive=True,
        power_splitter=True,
        ports=3,
        narrowband=True,
        dichroic_filter=True
    )

    settings = dict(
        width=1,  # input and output straight width. Defaults to cross_section width.
        width_taper=0.51,  # interface between input straights and mmi region.
        length_taper=[2, 15],  # into the mmi region.
        length_mmi=[2, 15],  # in x direction.
        width_mmi=[2, 6],  # in y direction.
        gap_mmi=[0.25, 0.25],  # gap between tapered wg.
        taper=0,  # taper function.
        cross_section='xs_sc'
    )

    wavelength = [1.53, 1.65]
    polarization = ['te']

    nominal_sparam = dict(  # power transmission in linear
        S11=0,
        S22=0,
        S33=1,
        S12=0.5,
        S21=0.5,
        S13=0.5,
        S31=0.5,
        S23=0,
        S32=0,
    )

    #        length_mmi
    #         <------>
    #         ________
    #        |        |
    #        |         \__
    #        |          __  o2
    #     __/          /_ _ _ _
    #  o1 __          | _ _ _ _| gap_mmi
    #       \          \__
    #        |          __  o3
    #        |         /
    #        |________|
    #      <->
    # length_taper

    # import gdsfactory as gf

    # c = gf.components.mmi1x2(width_taper=1.0, length_taper=10.0, length_mmi=5.5, width_mmi=2.5, gap_mmi=0.25, cross_section='xs_sc')
    # c.plot()
"""
### mmi 1x2, or 1x2 mmi, 
operating wavelength ranges from [1260nm to 1360nm], this device won't work at wavelength out of this range.
Properties of this device include:  number of ports equals 3 
"""
def mmi1x2_wavelength_1260_to_1360():

    # creates a 1x2 mmi (multi-mode interferometer) that only operates at wavelength from [1260nm to 1360nm]
    # this device won't work for wavelength out of this range
    # operating wavelength includes: 1260nm, 1261nm, 1262nm, 1263nm, 1264nm, 1265nm,
    # 1266nm, 1267nm, 1268nm, 1269nm, 1270nm, 1271nm,
    # 1272nm, 1273nm, 1274nm, 1275nm, 1276nm, 1277nm,
    # 1278nm, 1279nm, 1280nm, 1281nm, 1282nm, 1283nm,
    # 1284nm, 1285nm, 1286nm, 1287nm, 1288nm, 1289nm,
    # 1290nm, 1291nm, 1292nm, 1293nm, 1294nm, 1295nm,
    # 1296nm, 1297nm, 1298nm, 1299nm, 1300nm, 1301nm,
    # 1302nm, 1303nm, 1304nm, 1305nm, 1306nm, 1307nm,
    # 1308nm, 1309nm, 1310nm, 1311nm, 1312nm, 1313nm,
    # 1314nm, 1315nm, 1316nm, 1317nm, 1318nm, 1319nm,
    # 1320nm, 1321nm, 1322nm, 1323nm, 1324nm, 1325nm,
    # 1326nm, 1327nm, 1328nm, 1329nm, 1330nm, 1331nm,
    # 1332nm, 1333nm, 1334nm, 1335nm, 1336nm, 1337nm,
    # 1338nm, 1339nm, 1340nm, 1341nm, 1342nm, 1343nm,
    # 1344nm, 1345nm, 1346nm, 1347nm, 1348nm, 1349nm,
    # 1350nm, 1351nm, 1352nm, 1353nm, 1354nm, 1355nm,
    # 1356nm, 1357nm, 1358nm, 1359nm, 1360nm

    # return gf.components.mmi1x2(width_taper=0.5, length_taper=10.0, length_mmi=1.8,
    # width_mmi=1.5, gap_mmi=0.3, width=0.41, cross_section='xs_sc')

    # Properties of this device include: silicon based , passive element , power splitter , number of ports=3 , dichroic_filter


    name = 'mmi1x2'

    properties = dict(
        silicon=True,
        passive=True,
        power_splitter=True,
        ports=3,
        narrowband=True,
        dichroic_filter=True
    )

    settings = dict(
        width=0,            # input and output straight width. Defaults to cross_section width.
        width_taper=1.4,        # interface between input straights and mmi region.
        length_taper=[2, 15],       # into the mmi region.
        length_mmi=[2, 15] ,       # in x direction.
        width_mmi=[2, 6],          # in y direction.
        gap_mmi=[0.25, 0.25] ,           # gap between tapered wg.
        taper=0,              # taper function.
        cross_section='xs_sc'
    )

    wavelength = [1.26, 1.36]
    polarization = ['te']

    nominal_sparam = dict(     # power transmission in linear
        S11=0,
        S22=0,
        S33=0,
        S12=0.5,
        S21=0.5,
        S13=0.5,
        S31=0.5,
        S23=0,
        S32=0,
    )

    #        length_mmi
    #         <------>
    #         ________
    #        |        |
    #        |         \__
    #        |          __  o2
    #     __/          /_ _ _ _
    #  o1 __          | _ _ _ _| gap_mmi
    #       \          \__
    #        |          __  o3
    #        |         /
    #        |________|
    #      <->
    # length_taper


    # import gdsfactory as gf

    # c = gf.components.mmi1x2(width_taper=1.0, length_taper=10.0, length_mmi=5.5, width_mmi=2.5, gap_mmi=0.25, cross_section='xs_sc')
    # c.plot()


"""
### MMI 2x2, operating wavelength ranges from [1530nm to 1565nm], this device won't work at wavelength out of this range. Properties of this device include: silicon based , passive element , power_splitter , number of ports=4
"""


def mmi2x2_wavelength_1530_to_1565():

    # creates a 2x2 mmi (multi-mode interferometer) that only operates at wavelength from [1530nm to 1565nm]
    # this device won't work for wavelength out of this range
    # operating wavelength includes: 1530nm, 1531nm, 1532nm, 1533nm, 1534nm, 1535nm, 1536nm, 1537nm, 1538nm, 1539nm,
    # 1540nm, 1541nm, 1542nm, 1543nm, 1544nm,
    # 1545nm, 1546nm, 1547nm, 1548nm, 1549nm, 1550nm, 1551nm, 1552nm,
    # 1553nm, 1554nm, 1555nm, 1556nm, 1557nm, 1558nm, 1559nm, 1560nm, 1561nm, 1562nm, 1563nm, 1564nm, 1565nm

    return gf.components.mmi2x2(width_taper=1.3, length_taper=15.0, length_mmi=36.2,
                                width_mmi=5.5, gap_mmi=0.27, cross_section='xs_sc')


"""
## Edge Coupler Silicon, operating wavelength ranges from [1530nm to 1565nm], this device won't work at wavelength out of this range
"""


def edge_coupler_wavelength_1530_to_1565():

    # creates an edge coupler that only operates at wavelength from [1530nm to 1565nm]
    # this device won't work for wavelength out of this range
    # operating wavelength includes: 1530nm, 1531nm, 1532nm, 1533nm, 1534nm, 1535nm, 1536nm, 1537nm, 1538nm, 1539nm,
    # 1540nm, 1541nm, 1542nm, 1543nm, 1544nm,
    # 1545nm, 1546nm, 1547nm, 1548nm, 1549nm, 1550nm, 1551nm, 1552nm,
    # 1553nm, 1554nm, 1555nm, 1556nm, 1557nm, 1558nm, 1559nm, 1560nm, 1561nm, 1562nm, 1563nm, 1564nm, 1565nm

    return gf.components.edge_coupler_silicon(length=150.0, width1=0.2, width2=0.5,
                                              with_two_ports=True, cross_section='xs_sc',
                                              port_order_name=['o1', 'o2'],
                                              port_order_types=['optical', 'optical'])


"""
## Edge Coupler Silicon, operating wavelength ranges from [1260nm to 1360nm], this device won't work at wavelength out of this range
"""
def edge_coupler_wavelength_1260_to_1360():

    # creates an edge coupler that only operates at wavelength from [1260nm to 1360nm]
    # this device won't work for wavelength out of this range
    # operating wavelength includes: 1260nm, 1261nm, 1262nm, 1263nm, 1264nm, 1265nm,
    # 1266nm, 1267nm, 1268nm, 1269nm, 1270nm, 1271nm,
    # 1272nm, 1273nm, 1274nm, 1275nm, 1276nm, 1277nm,
    # 1278nm, 1279nm, 1280nm, 1281nm, 1282nm, 1283nm,
    # 1284nm, 1285nm, 1286nm, 1287nm, 1288nm, 1289nm,
    # 1290nm, 1291nm, 1292nm, 1293nm, 1294nm, 1295nm,
    # 1296nm, 1297nm, 1298nm, 1299nm, 1300nm, 1301nm,
    # 1302nm, 1303nm, 1304nm, 1305nm, 1306nm, 1307nm,
    # 1308nm, 1309nm, 1310nm, 1311nm, 1312nm, 1313nm,
    # 1314nm, 1315nm, 1316nm, 1317nm, 1318nm, 1319nm,
    # 1320nm, 1321nm, 1322nm, 1323nm, 1324nm, 1325nm,
    # 1326nm, 1327nm, 1328nm, 1329nm, 1330nm, 1331nm,
    # 1332nm, 1333nm, 1334nm, 1335nm, 1336nm, 1337nm,
    # 1338nm, 1339nm, 1340nm, 1341nm, 1342nm, 1343nm,
    # 1344nm, 1345nm, 1346nm, 1347nm, 1348nm, 1349nm,
    # 1350nm, 1351nm, 1352nm, 1353nm, 1354nm, 1355nm,
    # 1356nm, 1357nm, 1358nm, 1359nm, 1360nm
    return gf.components.edge_coupler_silicon(length=200.0, width1=0.2, width2=0.41,
                                              with_two_ports=True, cross_section='xs_sc',
                                              port_order_name=['o1', 'o2'],
                                              port_order_types=['optical', 'optical'])


"""
## TE Grating Coupler designed for TE polarized light, its operating wavelength ranges from [1530nm to 1565nm], this device won't work at wavelength out of this range
"""


def te_grating_coupler_wavelength_1530_to_1565():

    # creates a grating coupler for TE polarized light that only operates at wavelength from [1530nm to 1565nm]
    # this device won't work for wavelength out of this range
    # operating wavelength includes: 1530nm, 1531nm, 1532nm, 1533nm, 1534nm, 1535nm, 1536nm, 1537nm, 1538nm, 1539nm,
    # 1540nm, 1541nm, 1542nm, 1543nm, 1544nm,
    # 1545nm, 1546nm, 1547nm, 1548nm, 1549nm, 1550nm, 1551nm, 1552nm,
    # 1553nm, 1554nm, 1555nm, 1556nm, 1557nm, 1558nm, 1559nm, 1560nm, 1561nm, 1562nm, 1563nm, 1564nm, 1565nm

    return gf.components.grating_coupler_elliptical_uniform(n_periods=32, period=0.63,
                                                            fill_factor=0.5)

"""
## TE Grating Coupler designed for TE polarized light, its operating wavelength ranges from [1260nm to 1360nm], this device won't work at wavelength out of this range
"""

def te_grating_coupler_wavelength_1260_to_1360():

    # creates a grating coupler for TE polarized light that only operates at wavelength from [1530nm to 1565nm]
    # this device won't work for wavelength out of this range
    # operating wavelength includes: 1260nm, 1261nm, 1262nm, 1263nm, 1264nm, 1265nm,
    # 1266nm, 1267nm, 1268nm, 1269nm, 1270nm, 1271nm,
    # 1272nm, 1273nm, 1274nm, 1275nm, 1276nm, 1277nm,
    # 1278nm, 1279nm, 1280nm, 1281nm, 1282nm, 1283nm,
    # 1284nm, 1285nm, 1286nm, 1287nm, 1288nm, 1289nm,
    # 1290nm, 1291nm, 1292nm, 1293nm, 1294nm, 1295nm,
    # 1296nm, 1297nm, 1298nm, 1299nm, 1300nm, 1301nm,
    # 1302nm, 1303nm, 1304nm, 1305nm, 1306nm, 1307nm,
    # 1308nm, 1309nm, 1310nm, 1311nm, 1312nm, 1313nm,
    # 1314nm, 1315nm, 1316nm, 1317nm, 1318nm, 1319nm,
    # 1320nm, 1321nm, 1322nm, 1323nm, 1324nm, 1325nm,
    # 1326nm, 1327nm, 1328nm, 1329nm, 1330nm, 1331nm,
    # 1332nm, 1333nm, 1334nm, 1335nm, 1336nm, 1337nm,
    # 1338nm, 1339nm, 1340nm, 1341nm, 1342nm, 1343nm,
    # 1344nm, 1345nm, 1346nm, 1347nm, 1348nm, 1349nm,
    # 1350nm, 1351nm, 1352nm, 1353nm, 1354nm, 1355nm,
    # 1356nm, 1357nm, 1358nm, 1359nm, 1360nm
    return gf.components.grating_coupler_elliptical_uniform(n_periods=32, period=0.51,
                                                            fill_factor=0.5)


"""
## Directional Coupler, operating wavelength is at 1550nm, wavelength other than 1550nm will not be valid
"""


def directional_coupler_wavelength_1550():

    # creates a directional coupler that only operates at wavelength of 1550nm
    # this device won't work for wavelength out of this range
    # operating wavelength is only 1550nm

    return gf.components.coupler(gap=0.3, length=9.8, dy=55.0, dx=36.0,
                                 cross_section='xs_sc')


"""
## PIN Diode/VOA, operating wavelength ranges from [1530nm to 1565nm], this device won't work at wavelength out of this range
"""


def pin_diode_wavelength_1530_to_1565():

    # creates a pin diode that only operates at wavelength from [1530nm to 1565nm]
    # this device won't work for wavelength out of this range
    # operating wavelength includes: 1530nm, 1531nm, 1532nm, 1533nm, 1534nm, 1535nm, 1536nm, 1537nm, 1538nm, 1539nm,
    # 1540nm, 1541nm, 1542nm, 1543nm, 1544nm,
    # 1545nm, 1546nm, 1547nm, 1548nm, 1549nm, 1550nm, 1551nm, 1552nm,
    # 1553nm, 1554nm, 1555nm, 1556nm, 1557nm, 1558nm, 1559nm, 1560nm, 1561nm, 1562nm, 1563nm, 1564nm, 1565nm

    return gf.components.straight_pin(length=1000.0, via_stack_width=7.3,
                                      via_stack_spacing=2.3)


"""
## Splitter Tree, operating wavelength ranges from [1530nm to 1565nm], this device won't work at wavelength out of this range
"""


def splitter_tree_wavelength_1530_to_1565():

    # creates a splitter tree that only operates at wavelength from [1530nm to 1565nm]
    # this device won't work for wavelength out of this range
    # operating wavelength includes: 1530nm, 1531nm, 1532nm, 1533nm, 1534nm, 1535nm, 1536nm, 1537nm, 1538nm, 1539nm,
    # 1540nm, 1541nm, 1542nm, 1543nm, 1544nm,
    # 1545nm, 1546nm, 1547nm, 1548nm, 1549nm, 1550nm, 1551nm, 1552nm,
    # 1553nm, 1554nm, 1555nm, 1556nm, 1557nm, 1558nm, 1559nm, 1560nm, 1561nm, 1562nm, 1563nm, 1564nm, 1565nm

    return gf.components.splitter_tree(
        coupler=gf.components.mmi1x2(width_mmi=3.8, Length_mmi=12.8, gap_mmi=0.25),
        noutputs=4, spacing=[90.0, 50.0], cross_section='xs_sc')


"""
## Splitter Tree, operating wavelength ranges from [1260nm to 1360nm], this device won't work at wavelength out of this range
"""
def splitter_tree_wavelength_1260_to_1360():

    # creates a splitter tree that only operates at wavelength from [1260nm to 1360nm]
    # this device won't work for wavelength out of this range
    # operating wavelength includes: 1260nm, 1261nm, 1262nm, 1263nm, 1264nm, 1265nm,
    # 1266nm, 1267nm, 1268nm, 1269nm, 1270nm, 1271nm,
    # 1272nm, 1273nm, 1274nm, 1275nm, 1276nm, 1277nm,
    # 1278nm, 1279nm, 1280nm, 1281nm, 1282nm, 1283nm,
    # 1284nm, 1285nm, 1286nm, 1287nm, 1288nm, 1289nm,
    # 1290nm, 1291nm, 1292nm, 1293nm, 1294nm, 1295nm,
    # 1296nm, 1297nm, 1298nm, 1299nm, 1300nm, 1301nm,
    # 1302nm, 1303nm, 1304nm, 1305nm, 1306nm, 1307nm,
    # 1308nm, 1309nm, 1310nm, 1311nm, 1312nm, 1313nm,
    # 1314nm, 1315nm, 1316nm, 1317nm, 1318nm, 1319nm,
    # 1320nm, 1321nm, 1322nm, 1323nm, 1324nm, 1325nm,
    # 1326nm, 1327nm, 1328nm, 1329nm, 1330nm, 1331nm,
    # 1332nm, 1333nm, 1334nm, 1335nm, 1336nm, 1337nm,
    # 1338nm, 1339nm, 1340nm, 1341nm, 1342nm, 1343nm,
    # 1344nm, 1345nm, 1346nm, 1347nm, 1348nm, 1349nm,
    # 1350nm, 1351nm, 1352nm, 1353nm, 1354nm, 1355nm,
    # 1356nm, 1357nm, 1358nm, 1359nm, 1360nm
    return gf.components.splitter_tree(
        coupler=gf.components.mmi1x2(width_mmi=1.5, Length_mmi=1.8, gap_mmi=0.3),
        noutputs=4, spacing=[90.0, 50.0], cross_section='xs_sc')


"""
## Balanced MZI_phase_shifter, operating wavelength ranges from [1530nm to 1565nm], this device won't work at wavelength out of this range
"""


def balanced_mzi_phase_shifter_wavelength_1530_to_1565():

    # creates a balanced mzi phase shifter that only operates at wavelength from [1530nm to 1565nm]
    # this device won't work for wavelength out of this range
    # operating wavelength includes: 1530nm, 1531nm, 1532nm, 1533nm, 1534nm, 1535nm, 1536nm, 1537nm, 1538nm, 1539nm,
    # 1540nm, 1541nm, 1542nm, 1543nm, 1544nm,
    # 1545nm, 1546nm, 1547nm, 1548nm, 1549nm, 1550nm, 1551nm, 1552nm,
    # 1553nm, 1554nm, 1555nm, 1556nm, 1557nm, 1558nm, 1559nm, 1560nm, 1561nm, 1562nm, 1563nm, 1564nm, 1565nm

    return gf.components.mzi_phase_shifter(delta_length=0.0, length_y=2.5, length_x=320.0,
                                           straight_x_top='straight_heater_metal',
                                           straight_x_bot='straight_metal_heater',
                                           splitter='mmi1x2', with_splitter=True,
                                           port_e1_splitter='o2', port_e0_splitter='o3',
                                           port_e1_combiner='o2', port_e0_combiner='o3',
                                           nbends=2, cross_section='xs_sc',
                                           mirror_bot=False, add_optical_ports_arms=False,
                                           add_electrical_ports_bot=True, min_length=0.01)


"""
## Balanced MZI_phase_shifter, operating wavelength ranges from [1260nm to 1360nm], this device won't work at wavelength out of this range
"""

def balanced_mzi_phase_shifter_wavelength_1260_to_1360():

    # creates a balanced mzi phase shifter that only operates at wavelength from [1260nm to 1360nm]
    # this device won't work for wavelength out of this range
    # operating wavelength includes: 1260nm, 1261nm, 1262nm, 1263nm, 1264nm, 1265nm,
    # 1266nm, 1267nm, 1268nm, 1269nm, 1270nm, 1271nm,
    # 1272nm, 1273nm, 1274nm, 1275nm, 1276nm, 1277nm,
    # 1278nm, 1279nm, 1280nm, 1281nm, 1282nm, 1283nm,
    # 1284nm, 1285nm, 1286nm, 1287nm, 1288nm, 1289nm,
    # 1290nm, 1291nm, 1292nm, 1293nm, 1294nm, 1295nm,
    # 1296nm, 1297nm, 1298nm, 1299nm, 1300nm, 1301nm,
    # 1302nm, 1303nm, 1304nm, 1305nm, 1306nm, 1307nm,
    # 1308nm, 1309nm, 1310nm, 1311nm, 1312nm, 1313nm,
    # 1314nm, 1315nm, 1316nm, 1317nm, 1318nm, 1319nm,
    # 1320nm, 1321nm, 1322nm, 1323nm, 1324nm, 1325nm,
    # 1326nm, 1327nm, 1328nm, 1329nm, 1330nm, 1331nm,
    # 1332nm, 1333nm, 1334nm, 1335nm, 1336nm, 1337nm,
    # 1338nm, 1339nm, 1340nm, 1341nm, 1342nm, 1343nm,
    # 1344nm, 1345nm, 1346nm, 1347nm, 1348nm, 1349nm,
    # 1350nm, 1351nm, 1352nm, 1353nm, 1354nm, 1355nm,
    # 1356nm, 1357nm, 1358nm, 1359nm, 1360nm
    return gf.components.mzi_phase_shifter(delta_length=0.0, length_y=2.6, length_x=320.0,
                                           splitter='mmi1x2', with_splitter=True,
                                           port_e1_splitter='o2', port_e0_splitter='o3',
                                           port_e1_combiner='o2', port_e0_combiner='o3',
                                           nbends=2, cross_section='xs_sc',
                                           mirror_bot=False, add_optical_ports_arms=False,
                                           add_electrical_ports_bot=True, min_length=0.01)


"""
## Mach-Zehnder interferometer (MZI), operating wavelength ranges from [1530nm to 1565nm], this device won't work at wavelength out of this range
"""


def mzi_wavelength_1530_to_1565():

    # creates a mzi (mach zehnder interferometer) that only operates at wavelength from [1530nm to 1565nm]
    # this device won't work for wavelength out of this range
    # operating wavelength includes: 1530nm, 1531nm, 1532nm, 1533nm, 1534nm, 1535nm, 1536nm, 1537nm, 1538nm, 1539nm,
    # 1540nm, 1541nm, 1542nm, 1543nm, 1544nm,
    # 1545nm, 1546nm, 1547nm, 1548nm, 1549nm, 1550nm, 1551nm, 1552nm,
    # 1553nm, 1554nm, 1555nm, 1556nm, 1557nm, 1558nm, 1559nm, 1560nm, 1561nm, 1562nm, 1563nm, 1564nm, 1565nm

    return gf.components.mzi(delta_length=50.0, length_y=2.0, length_x=0.1,
                             splitter=gf.components.mmi1x2(width_mmi=3.8, length_mmi=12.8,
                                                           gap_mmi=0.25),
                             with_splitter=True, port_e1_splitter='o2',
                             port_e0_splitter='o3', port_e1_combiner='o2',
                             port_e0_combiner='o3', nbends=2, cross_section='xs_sc',
                             mirror_bot=False, add_optical_ports_arms=False,
                             add_electrical_ports_bot=True, min_length=0.01)

"""
## Mach-Zehnder interferometer (MZI), operating wavelength ranges from [1260nm to 1360nm], this device won't work at wavelength out of this range
"""
def mzi_wavelength_1260_to_1360():

    # creates a mzi (mach zehnder interferometer) that only operates at wavelength from [1260nm to 1360nm]
    # this device won't work for wavelength out of this range
    # operating wavelength includes: 1260nm, 1261nm, 1262nm, 1263nm, 1264nm, 1265nm,
    # 1266nm, 1267nm, 1268nm, 1269nm, 1270nm, 1271nm,
    # 1272nm, 1273nm, 1274nm, 1275nm, 1276nm, 1277nm,
    # 1278nm, 1279nm, 1280nm, 1281nm, 1282nm, 1283nm,
    # 1284nm, 1285nm, 1286nm, 1287nm, 1288nm, 1289nm,
    # 1290nm, 1291nm, 1292nm, 1293nm, 1294nm, 1295nm,
    # 1296nm, 1297nm, 1298nm, 1299nm, 1300nm, 1301nm,
    # 1302nm, 1303nm, 1304nm, 1305nm, 1306nm, 1307nm,
    # 1308nm, 1309nm, 1310nm, 1311nm, 1312nm, 1313nm,
    # 1314nm, 1315nm, 1316nm, 1317nm, 1318nm, 1319nm,
    # 1320nm, 1321nm, 1322nm, 1323nm, 1324nm, 1325nm,
    # 1326nm, 1327nm, 1328nm, 1329nm, 1330nm, 1331nm,
    # 1332nm, 1333nm, 1334nm, 1335nm, 1336nm, 1337nm,
    # 1338nm, 1339nm, 1340nm, 1341nm, 1342nm, 1343nm,
    # 1344nm, 1345nm, 1346nm, 1347nm, 1348nm, 1349nm,
    # 1350nm, 1351nm, 1352nm, 1353nm, 1354nm, 1355nm,
    # 1356nm, 1357nm, 1358nm, 1359nm, 1360nm
    return gf.components.mzi(delta_length=50.0, length_y=2.1, length_x=0.2,
                             splitter=gf.components.mmi1x2(width_mmi=1.5, length_mmi=1.8,
                                                           gap_mmi=0.3),
                             with_splitter=True, port_e1_splitter='o2',
                             port_e0_splitter='o3', port_e1_combiner='o2',
                             port_e0_combiner='o3', nbends=2, cross_section='xs_sc',
                             mirror_bot=False, add_optical_ports_arms=False,
                             add_electrical_ports_bot=True, min_length=0.01)
