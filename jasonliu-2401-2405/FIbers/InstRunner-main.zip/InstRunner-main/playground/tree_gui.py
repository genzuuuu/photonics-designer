from fibers.data_loader.module_to_tree import get_tree_for_module

from inst_runner import tool_box
from playground import photonic_component_fiber

if __name__ == '__main__':
    tree = get_tree_for_module(photonic_component_fiber)
    tree.display()