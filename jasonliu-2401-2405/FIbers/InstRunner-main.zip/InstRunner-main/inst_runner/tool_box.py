import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from mllm import Chat
from inst_runner.tool_box_helper import matplotlib_plot_to_image


"""
# Data generation
"""

def generate_random_data(mean: float, std: float, size: int) -> np.ndarray:
    """
    Generate random data from a normal distribution.
    :param mean: The mean of the normal distribution.
    :param std: The standard deviation of the normal distribution.
    :param size: The size of the data.
    :return: The random data.
    """
    return np.random.normal(mean, std, size)


"""
# Large language model and vision models
"""


def ask_human(question: str):
    """
    Ask a human a question. You can use it when you need feedback from a human.
    :param question: The question for the human to answer.
    :return: The response from the human.
    """
    print("Human, please answer the following question:")
    print(question)
    res = input()
    return res



def ask_vision_model(image: "Image", question) -> bool:
    """
    Ask a question about the image. For example, what is in the image, or whether the image is a cat.
    The answer is either True or False.
    You should use it when you need to analyze the data.
    :param image: the image to ask about in PIL format.
    :param question: the question to ask.
    :return: the response to the question.
    """
    chat = Chat(
        system_message="You are a helpful assistant who only answer in `yes` of `no`")
    chat.add_image_message(image)
    chat.add_user_message(question)
    res = chat.complete()
    if "yes" in res.lower():
        return True
    else:
        return False


"""
# Text and Image Input/Output
"""


def display_image(image: Image):
    """
    Display an image.
    :param image: image to display
    :return: None
    """
    plt.imshow(image)
    # axis off
    plt.axis('off')
    plt.show()


"""
# Plot
"""

def draw_x_y_plot(x, y, x_label="", y_label="") -> Image:
    """
    Make an x-y plot.
    Args:
        x (np.ndarray): The x-axis data.
        y (np.ndarray): The y-axis data.
        x_label (str): The label for the x-axis.
        y_label (str): The label for the y-axis.
    :return: The image object.
    """
    plt.plot(x, y)
    plt.xlabel(x_label)
    plt.ylabel(y_label)
    # plt to fig
    fig = plt.gcf()
    img = matplotlib_plot_to_image(fig)
    return img

