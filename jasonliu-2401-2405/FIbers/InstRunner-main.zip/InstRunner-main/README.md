
# InstRunner

Translate natural language instructions to code.

## Development

Environment: PyCharm, Conda, Python 3.10

(**Important**) Update your project by when the dependency is updated: `pip install -I -r requirements.txt`

## Installation

```bash
pip install -r requirements.txt
```

If you didn't install node, run 

```bash
conda install nodejs
```